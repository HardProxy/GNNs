#!/bin/bash
# Setup de configuraçoes de


#Loading python 3.9 module on cluster
#module load gcc/8.4/python/3.9

# Libraries

#MLOps
pip3.9 install optuna
pip3.9 install tensorboard

#Visualization
pip3.9 install matplotlib

#Torch and Torch_Vision
pip3.9 install torch==1.9.0 torchvision==0.10.0 -f https://download.pytorch.org/whl/cu102/torch_stable.html

#Installing torch_geometric, torch_cluster, torch_sparse, torch_spline_conv
pip3.9 install torch-scatter torch-sparse torch-cluster torch-spline-conv torch-geometric -f https://pytorch-geometric.com/whl/torch-1.9.0+cu102.html

#Obs: caso der erro no scatter, cluster, spline-conv ou sparse
# pip3.9 uninstall _nome_do_pacote
# pip3.9 install _nome_do_pacote   
~                                                                                                        
~              
