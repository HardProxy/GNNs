import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, Linear
from torch_geometric.nn import global_mean_pool

#train, validation and test split
from torch_geometric.datasets import TUDataset
from torch_geometric.loader import DataLoader

import time 

import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, Linear
from torch_geometric.nn import global_mean_pool

class GCN(torch.nn.Module):
    def __init__(self, hidden_units,input_shape,out):
        super(GCN, self).__init__()
        # Convolutional Layers
        self.conv1 = GCNConv(input_shape, 8*hidden_units)
        self.conv2 = GCNConv(8*hidden_units, 4*hidden_units)
        self.conv3 = GCNConv(4*hidden_units, 2*hidden_units)
        self.conv4 = GCNConv(2*hidden_units, hidden_units)

        #Fully Connected Layer
        self.lin1 = Linear(hidden_units, hidden_units)
        self.lin2 = Linear(hidden_units, hidden_units)
        self.lin3 = Linear(hidden_units, out)
        
    def forward(self, x, edge_index, batch):

        x = self.conv1(x, edge_index)
        x = x.tanh()
        x = self.conv2(x, edge_index)
        x = x.tanh()
        x = self.conv3(x, edge_index)
        x = x.tanh()
        x = self.conv4(x, edge_index)

        x = F.dropout(x, p=0.5, training=self.training)

        x = self.lin1(x)
        x = x.tanh()
        x = self.lin2(x)
        x = x.tanh()
        x = self.lin3(x)
        x = global_mean_pool(x, batch)

        return x



dataset = TUDataset(root='data/TUDataset', name='QM9')
dataset = dataset.shuffle()
print(dataset)
#GPGPU or CPU 
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#device = torch.device('cpu')

print('Using ', device)
#training proportion
train_p = .7

# splitting 
print('Total Number of graphs on dataset: ', len(dataset))
train = dataset[:int(len(dataset)*train_p)]
test = dataset[int(len(dataset)*train_p):]
print(' Number of graph for training: ',len(train))
print(' Number of graphs for test: ', len(test))

in_channels = dataset.num_features
out_channels = dataset.num_classes #19 physical properties
hidden_units = 16
model = GCN(hidden_units, in_channels, out_channels).to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = torch.nn.MSELoss()

print(model)

print('Creating Loaders ...')
batch_size = 64
print(' Batch Size: ',batch_size)
train_loader = DataLoader(train, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test, batch_size=batch_size, shuffle=False)

# train function 
def train():
  model.train()
  # on batch
  for train_graph in train_loader:
    train_graph = train_graph.to(device)
    out = model(train_graph.x, train_graph.edge_index, train_graph.batch)
    loss = criterion(out, train_graph.y) # LOSS MSE for regression
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    #del loss
#test function
def test(test_loader):

    
  model.eval()

  test_loss = 0
  for test_graphs in test_loader:
    test_graphs = test_graphs.to(device) 
    predicted = model(test_graphs.x, test_graphs.edge_index, test_graphs.batch)
    #Cumulative Test Loss
    # .item() was used as optimization to acumulate
    test_loss += criterion(predicted, test_graphs.y).item()
  #Mean of all test loss
  return test_loss/ len(test_loader.dataset)

init_time = time.time()
# training fase
epochs = 400

import numpy as np
model_parameters = filter(lambda p: p.requires_grad, model.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print('Trainable params: ', params)

print('Epochs: ', epochs)
print('')

for epoch in range(1,epochs +1):
  train()
  train_loss = test(train_loader)
  val_loss = test(test_loader)
  print(f"Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")

print('Execution time: ', time.time() - init_time)
