# ML general puporse lib
import torch
import torch.nn as nn 
import torch.optim as optim

#GNN Model
from model import GCN

# Utils
from utils import dataset_info

# Torch Geometric 
from torch_geometric.nn import VGAE
from torch_geometric.nn import GCNConv

# Utils
from torch_geometric.utils import train_test_split_edges

# Hyperparameters optimizer
import optuna
from optuna.trial import TrialState

import time
import numpy as np 
import pandas as pd

from torch.utils.tensorboard import SummaryWriter



#train, validation and test split
from torch_geometric.datasets import TUDataset
from torch_geometric.loader import DataLoader

dataset = TUDataset(root='data/TUDataset', name='QM9')
dataset = dataset.shuffle()

#GPGPU or CPU 
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#device = torch.device('cpu')

# Parameters
epochs = 400

# GVAE Bottle Neck 
num_features = dataset.num_features

#Model
def define_GVAE_topology(trial):
    '''
    Função que cria escopo da topologia do GVAE

    return :
        GCN (torch_geometric.nn object)
    '''    
    in_channels = dataset.num_features
    out_classes = dataset.num_classes

    hidden_units = trial.suggest_int('hidden_nodes',2,128)
    
    gcn_model = GCN(hidden_units, in_channels, out_classes)
    
    return gcn_model

# Função base do Optuna
def objective(trial):
    
    # Generate Model
    model = define_GVAE_topology(trial).to(device)
    criterion = torch.nn.MSELoss()  # Define loss criterion.
    
    # Generate the optimizers.
    optimizer_name = trial.suggest_categorical("optimizer", ["Adam"])
    lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
    optimizer = getattr(optim, optimizer_name)(model.parameters(), lr=lr)

    # Train/Test Dataset split
    #training proportion
    train_p = .7

    # splitting 
    print('Total Number of graphs on dataset: ', len(dataset))
    train = dataset[:int(len(dataset)*train_p)]
    test = dataset[int(len(dataset)*train_p):]
    print(' Number of graph for training: ',len(train))
    print(' Number of graphs for test: ', len(test))

    print('Creating Loaders ...')
    batch_size = trial.suggest_int('batch_size',8,256)
    train_loader = DataLoader(train, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test, batch_size=batch_size, shuffle=False)
        
    # Tensorboard dashboard
    writer = SummaryWriter()
    init_data = time.time()
    
    print('Training ...')
    print(' Epochs:', epochs)
    #Train
    for epoch in range(1, epochs + 1):
        
        #Train
        model.train()
        # on batch
        for train_graph in train_loader:
            train_graph = train_graph.to(device)
            out = model(train_graph.x, train_graph.edge_index, train_graph.batch)
            loss = criterion(out, train_graph.y) # LOSS MSE for regression
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

        writer.add_scalar('Loss/train', loss,epoch)

        #Validation 
        model.eval()

        test_loss = 0
        for test_graphs in test_loader:
            test_graphs = test_graphs.to(device) 
            predicted = model(test_graphs.x, test_graphs.edge_index, test_graphs.batch)
            test_loss += criterion(predicted, test_graphs.y).item()
        
        writer.add_scalar('Loss/val', test_loss/ len(test_loader.dataset), epoch)
        
    # Metrics to save
    writer.close()    

        
    # Handle pruning based on the intermediate value.
    # This handle can not be used on multiple-objective optimizations
    #if trial.should_prune():
    #    raise optuna.exceptions.TrialPruned()

    exec_time = time.time() - init_data 

    print('Model trained ... ')
    #trial.report(auc,ap,exec_time)
    return test_loss/ len(test_loader.dataset),loss,exec_time


if __name__ == "__main__":
    start_time = time.time()
    
    #Study Name
    study_name = 'gcn_searchgrid'
    
    #Number of trials
    n_trials = 50
    
    
    #Maximize or Minimize metrics
    '''
    #saving on sql file
    study = optuna.create_study(storage='sqlite:///'+study_name+'.db',
                                study_name=study_name,
                                directions=['minimize','minimize','minimize'])
    '''

    study = optuna.create_study(study_name=study_name,
                                directions=['minimize','minimize','minimize'])

    study.optimize(objective, n_trials=n_trials)
    pruned_trials = study.get_trials(deepcopy=False, states=[TrialState.PRUNED])
    complete_trials = study.get_trials(deepcopy=False, states=[TrialState.COMPLETE])

    print("Study statistics: ")
    print("  Number of finished trials: ", len(study.trials))
    print("  Number of pruned trials: ", len(pruned_trials))
    print("  Number of complete trials: ", len(complete_trials))
    print('  Execution Time of Grid Search: ',time.time() - start_time)

    print("Best trials:")
    trials = study.best_trials
    best_list = []
    i = 0
    for models in trials:

        print("  Params Model {}:".format(i))
        for key, value in models.params.items():
            print("    {}: {}".format(key, value))

        best_list.append(models.params)
        
        i+=1

    #Saving on dataframe structure    
    #All trials
    df_all_trials = study.trials_dataframe()
    df_all_trials.to_csv('df_all_trials.csv',index=False)

    #Best trials
    df_best_trials = pd.DataFrame(best_list)
    df_best_trials.to_csv('df_best_trials.csv', index=False)
