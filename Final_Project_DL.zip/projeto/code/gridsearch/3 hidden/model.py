import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, Linear
from torch_geometric.nn import global_mean_pool

class GCN(torch.nn.Module):
    def __init__(self, hidden_units,input_shape,out):
        super(GCN, self).__init__()
        torch.manual_seed(12345)
        self.conv1 = GCNConv(input_shape, 4*hidden_units)
        self.conv2 = GCNConv(4*hidden_units, 2*hidden_units)
        self.conv3 = GCNConv(2*hidden_units, hidden_units)

        self.linear = Linear(hidden_units, out)

    def forward(self, x, edge_index, batch):
        x = self.conv1(x, edge_index)
        x = x.relu()
        x = self.conv2(x, edge_index)
        x = x.relu()
        x = self.conv3(x, edge_index)

        x = F.dropout(x, p=0.5, training=self.training)

        x = global_mean_pool(x, batch)

        x = self.linear(x)
        return x
